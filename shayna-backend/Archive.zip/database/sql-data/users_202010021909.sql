INSERT INTO db.users (name,email,email_verified_at,password,remember_token,created_at,updated_at) VALUES 
('ade suhada','dev.suhada@gmail.com',NULL,'$2y$10$M67/Mpz7c7TGatdZvPNec.Qqh3YtJ.eUiminkrpbpri5x7fJ3YRb2',NULL,'2020-10-02 10:42:11.0','2020-10-02 10:42:11.0')
;