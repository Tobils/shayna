INSERT INTO db.transaction_details (transactions_id,products_id,deleted_at,created_at,updated_at) VALUES 
(1,1,NULL,'2020-10-02 11:50:19.0','2020-10-02 11:50:19.0')
,(1,1,NULL,'2020-10-02 11:50:19.0','2020-10-02 11:50:19.0')
;