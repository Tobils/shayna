INSERT INTO db.transactions (uuid,name,email,`number`,address,transaction_total,transaction_status,deleted_at,created_at,updated_at) VALUES 
('TRX762768570','tobil','suhada@gmail.com','085228663237','cileungsi, bogor',440,'PENDING',NULL,'2020-10-02 11:50:19.0','2020-10-02 11:50:19.0')
;