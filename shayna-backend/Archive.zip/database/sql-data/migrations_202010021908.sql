INSERT INTO db.migrations (migration,batch) VALUES 
('2014_10_12_000000_create_users_table',1)
,('2014_10_12_100000_create_password_resets_table',1)
,('2019_08_19_000000_create_failed_jobs_table',1)
,('2020_09_05_013050_create_products_table',1)
,('2020_09_16_134143_create_product_galleries_table',1)
,('2020_09_16_135208_create_transactions_table',1)
,('2020_09_16_220352_create_transaction_details_table',1)
,('2020_09_24_043912_create_mahasiswa_table',1)
;