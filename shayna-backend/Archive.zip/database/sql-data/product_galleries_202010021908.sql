INSERT INTO db.product_galleries (products_id,photo,is_default,deleted_at,created_at,updated_at) VALUES 
(1,'assets/product/JaGLvUaRnQjg28756xR6PgzeLw7NTX5U4KhYwx11.jpeg',1,NULL,'2020-10-02 11:48:07.0','2020-10-02 11:48:07.0')
;